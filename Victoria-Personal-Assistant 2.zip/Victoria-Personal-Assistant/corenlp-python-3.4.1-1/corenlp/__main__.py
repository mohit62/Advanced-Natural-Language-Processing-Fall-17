from . import corenlp

corenlp.main()
